package actividad6;

import java.util.Scanner;

public class Actividad6 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Alumno alumno = new Alumno();
        alumno.nombre = "Judith";
        double promedio;
        promedio = promedio(alumno.calificacion);
        
        String calificacion = calificacion(promedio);
        imprimirCalificacion(alumno, promedio, calificacion);   
    }
    
    public static Double promedio(Double[] calificacion) {
       
         double promedio = 0 ;
         Alumno alumno = new Alumno();
         double acu = 0;
         Scanner cali = new Scanner (System.in);
         int calif;
         
        for(int i=0; i < alumno.calificacion.length; i++)
        {
            System.out.println("La calificacion " + (i+1) + " es: ");
            calif = cali.nextInt();
            acu = acu + calif;
        }
        
        promedio = acu / alumno.calificacion.length;
        
        return promedio;
    }

    public static String calificacion(Double promedio) {
        String calificacion = "";
        if (promedio <= 50) {
            calificacion = "F";
        }
        if (promedio >= 51 && promedio <= 60) {
            calificacion = "E";
        }
        if (promedio >= 61 && promedio <= 70) {
            calificacion = "D";
        }
        if (promedio >= 71 && promedio <= 80) {
            calificacion = "C";
        }
        if (promedio >= 81 && promedio <= 90) {
            calificacion = "B";
        }
        if (promedio >= 91 && promedio <= 100) {
            calificacion = "A";
        }
        return calificacion;
    }

    public static void imprimirCalificacion(Alumno alumno, Double promedio, String calificacion) {
        System.out.println("Nombre del estudiante: " + alumno.nombre);
        
        for (int i = 0; i < 5; i++)
        {
            System.out.println("Promedio: " + promedio);
            System.out.println("Calificacion: " + calificacion);
        }
    }
    
}
