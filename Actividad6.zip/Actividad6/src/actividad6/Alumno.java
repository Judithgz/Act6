
package actividad6;

public class Alumno {
    public String nombre;
     public Double[] calificacion = new Double[4];
}
